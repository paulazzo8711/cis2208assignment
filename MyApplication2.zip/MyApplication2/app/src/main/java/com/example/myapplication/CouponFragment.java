package com.example.myapplication;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapplication.Adapter.CouponAdapter;
import com.example.myapplication.Model.CouponModel;

import java.util.ArrayList;
import java.util.List;


public class CouponFragment extends Fragment {


    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";


    private String mParam1;
    private String mParam2;
    private DrawerLayout drawer;
    private ImageView burgerIcon;
    private List<CouponModel> CouponModelList=new ArrayList<>();
    private RecyclerView rvCoupons;

    public CouponFragment() {
        // Required empty public constructor
    }

    public static CouponFragment newInstance(String param1, String param2) {
        CouponFragment fragment = new CouponFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }


    ArrayList<CouponModel> CouponList;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_coupon, container, false);

        DatabaseHelper db = new DatabaseHelper(getContext());
// Initialize the CouponModelList with some dummy data
        CouponModelList.add(new CouponModel(R.drawable.ic_dove_soap_icon, "5%", "All Dove Shower gels"));
        CouponModelList.add(new CouponModel(R.drawable.ic_barilla_pesto_icon, "15%", "All Barilla Pestos"));
        CouponModelList.add(new CouponModel(R.drawable.ic_kelloggs_icon, "11%", "All Kelloggs cereals"));
        CouponModelList.add(new CouponModel(R.drawable.ic_ariel_icon, "9%", "All ariel pods"));
        CouponModelList.add(new CouponModel(R.drawable.ic_nivea_deo_men_icon, "13%", "All Nivea Men Deoderants"));


        rvCoupons = view.findViewById(R.id.rv_coupons);
        com.example.myapplication.Adapter.CouponAdapter CouponAdapter = new CouponAdapter(getActivity(), CouponModelList);
        rvCoupons.setLayoutManager(new GridLayoutManager(getActivity(), 1, RecyclerView.VERTICAL, false));
        rvCoupons.setItemAnimator(new DefaultItemAnimator());
        rvCoupons.setAdapter(CouponAdapter);
        // Retrieve the Coupon list from the arguments (if provided)
        Bundle arguments = getArguments();
        if (arguments != null) {
            CouponList = (ArrayList<CouponModel>) arguments.getSerializable("CouponList");
        }

        return view;
    }

}