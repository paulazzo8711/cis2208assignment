package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_register);
        MaterialButton registerbtn = (MaterialButton) findViewById(R.id.registerbtn);
        MaterialButton loginbtn = (MaterialButton) findViewById(R.id.loginbtn);
        DatabaseHelper db;
        EditText editTextUsername, editTextPassword;
        EditText editTextFullName, editTextTelephone, editTextGender;
        db = new DatabaseHelper(this);
        editTextFullName = (EditText) findViewById(R.id.fullname);
        editTextUsername = (EditText) findViewById(R.id.email);
        editTextTelephone = (EditText) findViewById(R.id.telephone);
        editTextGender = (EditText) findViewById(R.id.gender);
        editTextPassword = (EditText) findViewById(R.id.password);
        FloatingActionButton backbtn = findViewById(R.id.backbtn);

        // Handle back button click
        backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
        // Handle register button click
        registerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get input values
                String fullName = editTextFullName.getText().toString();
                String username = editTextUsername.getText().toString();
                String telephone = editTextTelephone.getText().toString();
                String gender = editTextGender.getText().toString();
                String password = editTextPassword.getText().toString();
                //used for testing
            //    Log.d("RegisterActivity", "Username: " + username);
              //  Log.d("RegisterActivity", "FullName: " + fullName);
                //Log.d("RegisterActivity", "Telephone: " + telephone);
                //Log.d("RegisterActivity", "Gender: " + gender);
                //Log.d("RegisterActivity", "Password: " + password);

                // Check if any field is empty
                if (username.equals("") || password.equals("") || fullName.equals("") || telephone.equals("") || gender.equals("")) {
                    Toast.makeText(getApplicationContext(), "Fields are empty", Toast.LENGTH_SHORT).show();
                } else {
                    // Check if the username already exists
                    if (db.checkUsername(username)) {
                        Toast.makeText(getApplicationContext(), "Username already exists", Toast.LENGTH_SHORT).show();
                    } else {
                        // Insert user data into the database
                        if (db.insertData(username, password, fullName, telephone, gender)) {
                            Toast.makeText(getApplicationContext(), "Registration successful", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                            startActivity(intent);
                            // Retrieve and display the registered user's data
                          /*  Cursor cursor = db.getUserData(username);
                            if (cursor.moveToFirst()) {
                                Log.d("RegisterActivity", "ID: " + cursor.getString(0));
                                Log.d("RegisterActivity", "Username: " + cursor.getString(2));
                                Log.d("RegisterActivity", "Password: " + cursor.getString(5));
                                Log.d("RegisterActivity", "Full Name: " + cursor.getString(1));
                                Log.d("RegisterActivity", "Telephone: " + cursor.getString(3));
                                Log.d("RegisterActivity", "Gender: " + cursor.getString(4));
                            }
                            cursor.close();*/
                        } else {
                            Toast.makeText(getApplicationContext(), "Registration failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                }

            }
        });




    }



            }



