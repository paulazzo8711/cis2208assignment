package com.example.myapplication.Model;

public class CouponModel {
    private int couponImage;
    private String couponPrice;
    private String couponConstraint;

    public CouponModel(int offerImage, String offerPrice, String offerConstraint) {
        this.couponImage = offerImage;
        this.couponPrice = offerPrice;
        this.couponConstraint = offerConstraint;
    }

    public int getCouponImage() {
        return couponImage;
    }

    public void setCouponImage(int couponImage) {
        this.couponImage = couponImage;
    }

    public String getCouponPrice() {
        return couponPrice;
    }

    public void setCouponPrice(String couponPrice) {
        this.couponPrice = couponPrice;
    }

    public String getCouponConstraint() {
        return couponConstraint;
    }

    public void setCouponConstraint(String couponConstraint) {
        this.couponConstraint = couponConstraint;
    }
}
