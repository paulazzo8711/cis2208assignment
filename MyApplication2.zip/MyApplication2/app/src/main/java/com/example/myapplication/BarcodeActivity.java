package com.example.myapplication;

import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;

public class BarcodeActivity extends AppCompatActivity {
    ImageView burgerIcon;
    DrawerLayout drawer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_barcode);

        // Initialize views
        ImageView qrCodeImageView = findViewById(R.id.qrCodeImageView);
        TextView userIdTextView = findViewById(R.id.userIdTextView);

        // Get the user's ID from the database
        SharedPreferences sharedPreferences = getSharedPreferences("MyApp", MODE_PRIVATE);
        String username = sharedPreferences.getString("username", null);
        String userId = username;

        // Get the barcode for the username from the database
        DatabaseHelper db = new DatabaseHelper(this);
        String barcode = db.getBarcode(username);

        try {
            // Generate QR code bitmap from the barcode
            Bitmap qrCode = generateQRCode(barcode);
            qrCodeImageView.setImageBitmap(qrCode);
        } catch (WriterException e) {
            Log.e("QrCodeActivity", "Error generating QR code", e);
            // Handle the error
        }
    }

    private Bitmap generateQRCode(String text) throws WriterException {
        // Generate a BitMatrix representing the QR code
        BitMatrix bitMatrix = new MultiFormatWriter().encode(text, BarcodeFormat.QR_CODE, 200, 200);

        // Create a Bitmap to store the QR code image
        Bitmap bitmap = Bitmap.createBitmap(200, 200, Bitmap.Config.RGB_565);

        // Iterate through each pixel of the BitMatrix and set the corresponding pixel in the Bitmap
        for (int x = 0; x < 200; x++) {
            for (int y = 0; y < 200; y++) {
                // Set the pixel to black if the corresponding BitMatrix pixel is true (1) or white if false (0)
                bitmap.setPixel(x, y, bitMatrix.get(x, y) ? Color.BLACK : Color.WHITE);
            }
        }

        return bitmap;
    }

    @Override
    public void onBackPressed() {
        // Handle back button press to close the drawer if it is open
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(Gravity.LEFT);
        } else {
            super.onBackPressed();
        }
    }
}
