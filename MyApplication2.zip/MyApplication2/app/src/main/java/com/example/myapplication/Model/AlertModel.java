package com.example.myapplication.Model;

public class AlertModel {
    private int alertImage;
    private String alertPrice;
    private String alertConstraint;

    public AlertModel(int offerImage, String offerPrice, String offerConstraint) {
        this.alertImage = offerImage;
        this.alertPrice = offerPrice;
        this.alertConstraint = offerConstraint;
    }

    public int getAlertImage() {
        return alertImage;
    }

    public void setAlertImage(int alertImage) {
        this.alertImage = alertImage;
    }

    public String getAlertPrice() {
        return alertPrice;
    }

    public void setAlertPrice(String alertPrice) {
        this.alertPrice = alertPrice;
    }

    public String getAlertConstraint() {
        return alertConstraint;
    }

    public void setAlertConstraint(String alertConstraint) {
        this.alertConstraint = alertConstraint;
    }
}
