package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapplication.Adapter.AlertAdapter;
import com.example.myapplication.Adapter.CouponAdapter;
import com.example.myapplication.Adapter.OfferAdapter;
import com.example.myapplication.Model.AlertModel;
import com.example.myapplication.Model.CouponModel;
import com.example.myapplication.Model.OfferModel;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private DrawerLayout drawer;
    private NavigationView navigationView;
    ImageView burgerIcon;

    RecyclerView rvOffers;
    RecyclerView rvAlerts;
    RecyclerView rvCoupons;


    @SuppressLint("Range")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        burgerIcon=findViewById(R.id.iv_burger_icon);
        drawer=findViewById(R.id.drawer_layout);
        burgerIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
drawer.openDrawer(Gravity.LEFT);
            }
        });
//


        //
        navigationView = findViewById(R.id.nav_view);
        navigationView.bringToFront();
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                Fragment selectedFragment = null;

                if (id == R.id.nav_home) {
                    selectedFragment = new HomeFragment();
                } else if (id == R.id.nav_coupons) {
                    selectedFragment = new CouponFragment();
                } else if (id == R.id.nav_barcode) {
                    selectedFragment = new BarcodeFragment();
                } else if (id == R.id.nav_rewards) {
                    selectedFragment = new OfferFragment();
                } else if (id == R.id.nav_change_password) {
                    startActivity(new Intent(MainActivity.this, ResetPasswordActivity.class));
                }
             else if (id == R.id.nav_sign_out) {
                    startActivity(new Intent(MainActivity.this, splashActivity.class));
            }

                if (selectedFragment != null) {
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.fragment_container, selectedFragment)
                            .commit();
                }

                DrawerLayout drawer = findViewById(R.id.drawer_layout);
                drawer.closeDrawer(GravityCompat.START);
                return true;
            }
        });
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, new HomeFragment())
                .commit();
        SharedPreferences sharedPreferences = getSharedPreferences("MyApp", MODE_PRIVATE);
        String username = sharedPreferences.getString("username", null);  // Default value is null

        // Get the header view from the NavigationView
        View headerView = navigationView.getHeaderView(0);

        // Get the TextViews from the header view
        TextView userNameTextView = (TextView) headerView.findViewById(R.id.username);
        TextView emailTextView = (TextView) headerView.findViewById(R.id.email);

        DatabaseHelper db = new DatabaseHelper(this);
        Cursor cursor = db.getUserData(username);

        // Update the TextViews
        if (cursor.moveToFirst()) {
            userNameTextView.setText(cursor.getString(cursor.getColumnIndex("FULLNAME")));
            emailTextView.setText(cursor.getString(cursor.getColumnIndex("USERNAME")));
        }

    }

    @Override
    public void onBackPressed() {
        if(drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(Gravity.LEFT);
        }else {
            super.onBackPressed();
        }
    }

}