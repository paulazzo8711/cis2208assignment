package com.example.myapplication.Adapter;

import android.content.Context;
import android.hardware.lights.LightState;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.myapplication.Model.AlertModel;
import com.example.myapplication.R;

import java.util.ArrayList;
import java.util.List;

public class AlertAdapter extends RecyclerView.Adapter<AlertAdapter.viewHolder> {
    private Context ctx;
    private List<AlertModel> alertModelList=new ArrayList<>();

    public AlertAdapter(Context ctx, List<AlertModel> alertModelList) {
        this.ctx = ctx;
        this.alertModelList = alertModelList;
    }

    @NonNull
    @Override
    public AlertAdapter.viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(ctx).inflate(R.layout.alerts,parent,false);
        return new AlertAdapter.viewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull AlertAdapter.viewHolder holder, int position) {
        final AlertModel alertModel=alertModelList.get(position);
        holder.alertPrice.setText(alertModel.getAlertPrice());
        holder.alertConstraint.setText(alertModel.getAlertConstraint());
        Glide.with(ctx).load(alertModel.getAlertImage()).into(holder.alertImage);
    }

    @Override
    public int getItemCount() {
        return alertModelList.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder {
        private ImageView alertImage;
        private TextView alertPrice,alertConstraint;
        public viewHolder(@NonNull View itemView) {
            super(itemView);
            alertImage= itemView.findViewById(R.id.iv_alertImage);
            alertPrice= itemView.findViewById(R.id.txt_alertprice);
            alertConstraint= itemView.findViewById(R.id.txt_alertconstraint);
        }
    }
}
