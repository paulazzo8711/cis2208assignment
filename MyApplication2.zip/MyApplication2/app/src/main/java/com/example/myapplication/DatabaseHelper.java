package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.UUID;

public class DatabaseHelper extends SQLiteOpenHelper {
    // Database and table constants
    private static final String DATABASE_NAME = "User.db";
    private static final String TABLE_NAME = "user_table";

    // Column names
    private static final String COL_1 = "ID";
    private static final String COL_3 = "USERNAME";
    private static final String COL_6 = "PASSWORD";
    private static final String COL_2 = "FULLNAME";
    private static final String COL_4 = "TELEPHONE";
    private static final String COL_5 = "GENDER";
    private static final String COL_7 = "POINTS";
    private static final String COL_8 = "BARCODE";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the table
        db.execSQL("CREATE TABLE " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, FULLNAME TEXT, USERNAME TEXT, TELEPHONE INTEGER, GENDER TEXT, PASSWORD TEXT, POINTS INTEGER, BARCODE TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop the table and recreate it on upgrade
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public String generateBarcode() {
        // Generate a unique barcode using UUID
        return UUID.randomUUID().toString();
    }

    public boolean insertData(String username, String password, String fullName, String telephone, String gender) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2, fullName);
        contentValues.put(COL_3, username);
        contentValues.put(COL_4, telephone);
        contentValues.put(COL_5, gender);
        contentValues.put(COL_6, password);
        contentValues.put(COL_7, 200);  // Default points value
        String barcode = generateBarcode();
        contentValues.put(COL_8, barcode);
        long result = db.insert(TABLE_NAME, null, contentValues);
        return result != -1;  // Return true if data inserted successfully, false otherwise
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        String[] columns = { COL_1 };
        String selection = COL_3 + "=? AND " + COL_6 + "=?";
        String[] selectionArgs = { username, password };
        Cursor cursor = db.query(TABLE_NAME, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        db.close();
        return count > 0;  // Return true if user exists, false otherwise
    }

    public boolean checkUsername(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME, new String[] {COL_1}, COL_2 + "=?", new String[] {username}, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        return count > 0;  // Return true if username exists, false otherwise
    }

    public Cursor getUserData(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE " + COL_3 + "=?", new String[] {username});
        return res;  // Return a Cursor containing the user data
    }

    public String getBarcode(String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("SELECT " + COL_8 + " FROM " + TABLE_NAME + " WHERE " + COL_3 + "=?", new String[]{username});
        if (res.getCount() == 0) {
            // Handle the case where the user does not exist
            return null;
        }
        res.moveToNext();
        return res.getString(0);  // Return the barcode value
    }

    public String getPoints(String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("SELECT " + COL_7 + " FROM " + TABLE_NAME + " WHERE " + COL_3 + "=?", new String[]{username});
        if (res.getCount() == 0) {
            // Handle the case where the user does not exist
            return null;
        }
        res.moveToNext();
        return res.getString(0);  // Return the points value
    }
}
