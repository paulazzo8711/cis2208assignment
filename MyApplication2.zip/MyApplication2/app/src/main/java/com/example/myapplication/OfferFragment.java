package com.example.myapplication;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapplication.Adapter.OfferAdapter;
import com.example.myapplication.Model.OfferModel;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link OfferFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class OfferFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;
    private DrawerLayout drawer;
    private ImageView burgerIcon;
    private List<OfferModel> offerModelList = new ArrayList<>();
    private RecyclerView rvOffers;

    public OfferFragment() {
        // Required empty public constructor
    }

    public static OfferFragment newInstance(String param1, String param2) {
        OfferFragment fragment = new OfferFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    ArrayList<OfferModel> offerList;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_offer, container, false);
        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences("MyApp", Context.MODE_PRIVATE);
        String username = sharedPreferences.getString("username", null);
        String userId = username;
        DatabaseHelper db = new DatabaseHelper(getContext());
        String points = db.getPoints(username);
        TextView pointsTextView = view.findViewById(R.id.points_text_view);

        // Populate offerModelList with data
        offerModelList.add(new OfferModel(R.drawable.ic_cave_bar_icon, "30 points", "10$ voucher from Cave Bar"));
        offerModelList.add(new OfferModel(R.drawable.ic_cave_bar_icon, "50 points", "20$ voucher from Cave Bar"));
        offerModelList.add(new OfferModel(R.drawable.ic_cave_bar_icon, "80 points", "30$ voucher from Cave Bar"));
        offerModelList.add(new OfferModel(R.drawable.ic_salumeria_gardens_icon, "30 points", "10$ voucher from Salumeria Gardens"));
        offerModelList.add(new OfferModel(R.drawable.ic_salumeria_gardens_icon, "50 points", "20$ voucher from Salumeria Gardens"));
        offerModelList.add(new OfferModel(R.drawable.ic_salumeria_gardens_icon, "80 points", "30$ voucher from Salumeria Gardens"));
        offerModelList.add(new OfferModel(R.drawable.ic_ocean_basket_icon, "30 points", "15$ voucher from Ocean Basket"));
        offerModelList.add(new OfferModel(R.drawable.ic_ocean_basket_icon, "50 points", "20$ voucher from Ocean Basket"));
        offerModelList.add(new OfferModel(R.drawable.ic_ocean_basket_icon, "80 points", "40$ voucher from Ocean Basket"));
        offerModelList.add(new OfferModel(R.drawable.ic_super_dry_icon, "10 points", "5$ voucher from Superdry"));
        offerModelList.add(new OfferModel(R.drawable.ic_super_dry_icon, "20 points", "10$ voucher from Superdry"));
        offerModelList.add(new OfferModel(R.drawable.ic_super_dry_icon, "30 points", "15$ voucher from Superdry"));
        offerModelList.add(new OfferModel(R.drawable.ic_air_malta_icon, "100 points", "50$ voucher from Air Malta"));
        offerModelList.add(new OfferModel(R.drawable.ic_air_malta_icon, "175 points", "100$ voucher from Air Malta"));
        offerModelList.add(new OfferModel(R.drawable.ic_air_malta_icon, "250 points", "150$ voucher from Air Malta"));

        String userPoints = points;
        pointsTextView.setText("Points: " + userPoints);

        rvOffers = view.findViewById(R.id.rv_offers);
        OfferAdapter offerAdapter = new OfferAdapter(getActivity(), offerModelList);
        rvOffers.setLayoutManager(new GridLayoutManager(getActivity(), 1, RecyclerView.VERTICAL, false));
        rvOffers.setItemAnimator(new DefaultItemAnimator());
        rvOffers.setAdapter(offerAdapter);

        // Retrieve the offer list
        Bundle arguments = getArguments();
        if (arguments != null) {
            offerList = (ArrayList<OfferModel>) arguments.getSerializable("offerList");
        }


        return view;
    }
}
