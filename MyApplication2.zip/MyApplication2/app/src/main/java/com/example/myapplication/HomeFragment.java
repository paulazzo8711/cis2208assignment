package com.example.myapplication;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.Adapter.AlertAdapter;
import com.example.myapplication.Adapter.CouponAdapter;
import com.example.myapplication.Adapter.OfferAdapter;
import com.example.myapplication.Model.AlertModel;
import com.example.myapplication.Model.CouponModel;
import com.example.myapplication.Model.OfferModel;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {
    private List<OfferModel> offerModelList=new ArrayList<>();
    private List<AlertModel> alertModelList=new ArrayList<>();
    private List<CouponModel> couponModelList=new ArrayList<>();
    private DrawerLayout drawer;
    private ImageView burgerIcon;
    private RecyclerView rvOffers;
    private RecyclerView rvAlerts;
    private RecyclerView rvCoupons;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // Retrieve the user's points from SharedPreferences
        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences("MyApp", Context.MODE_PRIVATE);
        String username = sharedPreferences.getString("username", null);
        String userId = username;
        DatabaseHelper db = new DatabaseHelper(getContext());
        String points = db.getPoints(username);
        TextView pointsTextView = view.findViewById(R.id.points_text_view);
        TextView couponsTextView = view.findViewById(R.id.coupons_text_view);
        TextView rewardsTextView = view.findViewById(R.id.rewards_text_view);
        String userPoints = points;
        pointsTextView.setText("Points: " + userPoints);

        drawer = getActivity().findViewById(R.id.drawer_layout); // Assuming drawer layout has the id "drawer_layout" in your activity_main.xml
        burgerIcon = getActivity().findViewById(R.id.iv_burger_icon); // Assuming burger icon has the id "iv_burger_icon" in your activity_main.xml

        // Initialize models

        offerModelList.add(new OfferModel(R.drawable.ic_cave_bar_icon, "80 points", "30$ voucher from Cave Bar"));
        offerModelList.add(new OfferModel(R.drawable.ic_salumeria_gardens_icon, "80 points", "30$ voucher from Salumeria Gardens"));
        offerModelList.add(new OfferModel(R.drawable.ic_ocean_basket_icon, "80 points", "40$ voucher from Ocean Basket"));
        offerModelList.add(new OfferModel(R.drawable.ic_super_dry_icon, "30 points", "15$ voucher from Superdry"));
        offerModelList.add(new OfferModel(R.drawable.ic_air_malta_icon, "250 points", "150$ voucher from Air Malta"));

        alertModelList.add(new AlertModel(R.drawable.ic_alert_icon, "Opening Hours :", "09:00AM - 11:00 Everyday"));

        couponModelList.add(new CouponModel(R.drawable.ic_dove_soap_icon, "5%", "All Dove Shower gels"));
        couponModelList.add(new CouponModel(R.drawable.ic_barilla_pesto_icon, "15%", "All Barilla Pestos"));
        couponModelList.add(new CouponModel(R.drawable.ic_kelloggs_icon, "11%", "All Kelloggs cereals"));
        couponModelList.add(new CouponModel(R.drawable.ic_ariel_icon, "9%", "All ariel pods"));
        couponModelList.add(new CouponModel(R.drawable.ic_nivea_deo_men_icon, "13%", "All Nivea Men Deoderants"));

        // Initialize RecyclerViews
        rvOffers = view.findViewById(R.id.rv_offers);
        OfferAdapter offerAdapter = new OfferAdapter(getActivity(), offerModelList);
        rvOffers.setLayoutManager(new GridLayoutManager(getActivity(), 1, RecyclerView.HORIZONTAL, false));
        rvOffers.setItemAnimator(new DefaultItemAnimator());
        rvOffers.setAdapter(offerAdapter);

        rvAlerts = view.findViewById(R.id.rv_alerts);
        AlertAdapter alertAdapter = new AlertAdapter(getActivity(), alertModelList);
        rvAlerts.setLayoutManager(new GridLayoutManager(getActivity(), 1, RecyclerView.HORIZONTAL, false));
        rvAlerts.setItemAnimator(new DefaultItemAnimator());
        rvAlerts.setAdapter(alertAdapter);

        rvCoupons = view.findViewById(R.id.rv_coupons);
        CouponAdapter couponAdapter = new CouponAdapter(getActivity(), couponModelList);
        rvCoupons.setLayoutManager(new GridLayoutManager(getActivity(), 1, RecyclerView.HORIZONTAL, false));
        rvCoupons.setItemAnimator(new DefaultItemAnimator());
        rvCoupons.setAdapter(couponAdapter);

        burgerIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawer.openDrawer(Gravity.LEFT);
            }
        });

        couponsTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToCouponsFragment();
            }
        });

        rewardsTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToRewardsFragment();
            }
        });

        return view;
    }

    private void goToCouponsFragment() {
        CouponFragment couponsFragment = new CouponFragment();
        FragmentManager fragmentManager = getFragmentManager();
        if (fragmentManager != null) {
            fragmentManager.beginTransaction()
                    .replace(R.id.fragment_container, couponsFragment)
                    .addToBackStack(null)
                    .commit();
        }
    }

    private void goToRewardsFragment() {
        OfferFragment rewardsFragment = new OfferFragment();
        FragmentManager fragmentManager = getFragmentManager();
        if (fragmentManager != null) {
            fragmentManager.beginTransaction()
                    .replace(R.id.fragment_container, rewardsFragment)
                    .addToBackStack(null)
                    .commit();
        }
    }
}
