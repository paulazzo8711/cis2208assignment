package com.example.myapplication;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;


public class BarcodeFragment extends Fragment {

    private ImageView qrCodeImageView;
    private TextView userIdTextView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_barcode, container, false);

        qrCodeImageView = view.findViewById(R.id.qrCodeImageView);
        userIdTextView = view.findViewById(R.id.userIdTextView);

        // Retrieve username from SharedPreferences
        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences("MyApp", Context.MODE_PRIVATE);
        String username = sharedPreferences.getString("username", null);

        // Set the user ID (assuming it's the same as the username)
        String userId = username;
        userIdTextView.setText(userId);

        // Retrieve barcode for the username from the database
        DatabaseHelper db = new DatabaseHelper(getContext());
        String barcode = db.getBarcode(username);

        try {
            // Generate QR code bitmap from the barcode
            Bitmap qrCode = generateQRCode(barcode);
            qrCodeImageView.setImageBitmap(qrCode);
        } catch (WriterException e) {
            Log.e("QrCodeFragment", "Error generating QR code", e);
            // Handle the error
        }

        return view;
    }

    private Bitmap generateQRCode(String text) throws WriterException {
        // Generate a BitMatrix representing the QR code
        BitMatrix bitMatrix = new MultiFormatWriter().encode(text, BarcodeFormat.QR_CODE, 200, 200);

        // Create a Bitmap to store the QR code image
        Bitmap bitmap = Bitmap.createBitmap(200, 200, Bitmap.Config.RGB_565);

        // Iterate through each pixel of the BitMatrix and set the corresponding pixel in the Bitmap
        for (int x = 0; x < 200; x++) {
            for (int y = 0; y < 200; y++) {
                // Set the pixel to black if the corresponding BitMatrix pixel is true (1) or white if false (0)
                bitmap.setPixel(x, y, bitMatrix.get(x, y) ? Color.BLACK : Color.WHITE);
            }
        }
        return bitmap;
    }
}


