package com.example.myapplication.Adapter;

import android.content.Context;
import android.hardware.lights.LightState;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.myapplication.Model.CouponModel;
import com.example.myapplication.R;

import java.util.ArrayList;
import java.util.List;

public class CouponAdapter extends RecyclerView.Adapter<CouponAdapter.viewHolder> {
    private Context ctx;
    private List<CouponModel> couponModelList=new ArrayList<>();

    public CouponAdapter(Context ctx, List<CouponModel> couponModelList) {
        this.ctx = ctx;
        this.couponModelList = couponModelList;
    }

    @NonNull
    @Override
    public CouponAdapter.viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(ctx).inflate(R.layout.coupons,parent,false);
        return new CouponAdapter.viewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull CouponAdapter.viewHolder holder, int position) {
        final CouponModel couponModel=couponModelList.get(position);
        holder.couponPrice.setText(couponModel.getCouponPrice());
        holder.couponConstraint.setText(couponModel.getCouponConstraint());
        Glide.with(ctx).load(couponModel.getCouponImage()).into(holder.couponImage);
    }

    @Override
    public int getItemCount() {
        return couponModelList.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder {
        private ImageView couponImage;
        private TextView couponPrice,couponConstraint;
        public viewHolder(@NonNull View itemView) {
            super(itemView);
            couponImage= itemView.findViewById(R.id.iv_couponImage);
            couponPrice= itemView.findViewById(R.id.txt_couponprice);
            couponConstraint= itemView.findViewById(R.id.txt_couponconstraint);
        }
    }
}
